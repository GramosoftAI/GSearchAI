"use client";

import { useState, useEffect } from "react";
import Sidebar from "../components/layout/Sidebar";
import Header from "../components/layout/Header";
import { Drawer } from "antd";
import { useStore } from "../hooks/useStore";
import { usePathname, useRouter } from "next/navigation";
import { getCookie } from "../config/cookies";
import Loader from "../components/provider/Loder";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Desktop: collapsed/expanded sidebar
  const [collapsed, setCollapsed] = useState(true);
  const [width, setWidth] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAdminMode, setIsAdminMode } = useStore();
  const pathname = usePathname();
  const router = useRouter();
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    const token = getCookie("AUTH_TOKEN");
    if (!token) {
      router.push("/login");
    } else {
      setAuthorized(true);
    }
  }, [pathname, router]);

  useEffect(() => {
    if (pathname.startsWith("/dashboard/admin")) {
      setIsAdminMode(true);
    } else {
      setIsAdminMode(false);
    }
  }, [pathname, setIsAdminMode]);

  useEffect(() => {
    const handleResize = () => {
      setWidth(window.innerWidth);
    };
    handleResize(); // initial value
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 769) {
        setCollapsed(true);
      }
    };
    handleResize(); // initial check
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  if (!authorized) {
    return <Loader />;
  }

  return (
    <div className="h-screen flex w-full relative bg-[var(--app-surface-muted)] overflow-hidden transition-colors duration-500">
      {/* Premium Background Decorative Elements */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#0fb5a1]/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-teal-50/20 rounded-full blur-[100px]" />
      </div>

      {/* Desktop Inline Sidebar - Hidden on mobile screens */}
      <div className="hidden sm:block flex-shrink-0 relative z-10 transition-all duration-500 border-r border-[var(--app-border)]">
        <Sidebar collapsed={collapsed}
          onToggle={() => setCollapsed((prev) => !prev)}
        />
      </div>

      {/* Mobile Drawer Sidebar - Shown on menu click, takes full screen width */}
      <Drawer
        zIndex={10000}
        placement="left"
        onClose={() => setMobileMenuOpen(false)}
        open={mobileMenuOpen}
        styles={{
          body: { padding: 0, background: 'var(--app-surface)' },
          content: { background: 'var(--app-surface)' }
        }}
        width="100%"
        closeIcon={null}
      >
        <Sidebar collapsed={false} onToggle={() => setMobileMenuOpen(false)} onItemClick={() => setMobileMenuOpen(false)} />
      </Drawer>

      {/* Main column - Independently Scrollable */}
      <div className="flex-1 flex flex-col relative z-10 h-full overflow-hidden">
        <Header onMenuClick={() => setMobileMenuOpen(true)} />

        {/* Page content - Scrollable area */}
        <main className="flex-1 w-full p-0 md:p-0 xl:p-0 overflow-y-auto custom-dashboard-scroll animate-in fade-in slide-in-from-bottom-4 duration-1000">
          <div className="max-w-[1600px] mx-auto">
            {children}
          </div>
        </main>
      </div>

      <style jsx global>{`
        :root {
          /* New Professional White & Teal Palette matching landing page */
          --color-teal: #0fb5a1;
          --color-white: #ffffff;
          
          --app-primary: var(--color-teal);
          --app-secondary: var(--color-white);
          
          --app-surface: #ffffff;
          --app-surface-muted: #f5f7fa;
          --app-border: #e5e9ef;
          --app-text: #14161f;
          --app-text-muted: #414856;
          --app-text-soft: #6b7280;
          --app-active-bg: #e3f7f3;
          --app-hover: #eef2f6;
        }

        [data-theme='dark'] {
          --app-surface: #14161f;
          --app-surface-muted: #0d0f17;
          --app-border: #2e3347;
          --app-text: #f8fafc;
          --app-text-muted: #cbd5e1;
          --app-text-soft: #94a3b8;
          --app-active-bg: #12352f;
          --app-hover: #1e212f;
          
          /* Force White elements to Dark in Dark Mode */
          --color-white: #14161f;
        }

        body {
          background-color: var(--app-surface-muted);
          color: var(--app-text);
          font-family: var(--font-plus-jakarta-sans), -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Modern Scrollbar */
        ::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        ::-webkit-scrollbar-track {
          background: transparent;
        }
        ::-webkit-scrollbar-thumb {
          background: var(--app-border);
          border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: var(--app-text-soft);
        }

        .custom-dashboard-scroll::-webkit-scrollbar {
          width: 4px;
        }
        .custom-dashboard-scroll::-webkit-scrollbar-thumb {
          background: var(--app-border);
          opacity: 0.5;
        }

        [data-theme='dark'] ::-webkit-scrollbar-thumb {
          background: #1e293b;
        }

        /* Ant Design Overrides to match Theme */
        .ant-drawer-portal {
          z-index: 99999 !important;
        }
        .ant-typography {
          color: var(--app-text) !important;
        }
        .ant-card {
          background: var(--app-surface) !important;
          border-color: var(--app-border) !important;
        }
        .ant-btn-primary {
          background-color: #0fb5a1 !important;
          border-color: #0fb5a1 !important;
        }
        .ant-btn-primary:hover {
          background-color: #0a8576 !important;
          border-color: #0a8576 !important;
        }
        .ant-modal-content {
          background: var(--app-surface) !important;
          color: var(--app-text) !important;
        }

        /* Premium Notification Styling */
        .ant-notification-notice {
          border-radius: 24px !important;
          padding: 20px 24px !important;
          box-shadow: 0 20px 40px rgba(0,0,0,0.1) !important;
          border: 1px solid var(--app-border) !important;
          background: var(--app-surface) !important;
          backdrop-filter: blur(10px);
          overflow: hidden !important;
        }

        .custom-toast-success {
          border-left: 6px solid #10b981 !important;
        }
        .custom-toast-success .ant-notification-notice-message {
          color: #10b981 !important;
          font-weight: 900 !important;
          text-transform: uppercase !important;
          letter-spacing: 0.1em !important;
          font-size: 12px !important;
        }
        .custom-toast-success .ant-notification-notice-description {
          color: var(--app-text) !important;
          font-weight: 700 !important;
          font-size: 14px !important;
        }

        .custom-toast-error {
          border-left: 6px solid #ef4444 !important;
        }
        .custom-toast-error .ant-notification-notice-message {
          color: #ef4444 !important;
          font-weight: 900 !important;
          text-transform: uppercase !important;
          letter-spacing: 0.1em !important;
          font-size: 12px !important;
        }
        .custom-toast-error .ant-notification-notice-description {
          color: var(--app-text) !important;
          font-weight: 700 !important;
          font-size: 14px !important;
        }

        [data-theme='dark'] .ant-notification-notice {
          background: rgba(10, 15, 29, 0.8) !important;
          border-color: rgba(255, 255, 255, 0.1) !important;
        }
      `}</style>
    </div>
  );
}
